class io {
    public void Print (String text){
        System.out.print(text);
    }
}